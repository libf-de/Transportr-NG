#pragma once

#import <Foundation/Foundation.h>

#define MLN_EXPORT __attribute__((visibility("default")))
